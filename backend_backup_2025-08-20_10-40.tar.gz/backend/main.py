from fastapi import FastAPI
from starlette.responses import RedirectResponse

# Создаём приложение FastAPI
app = FastAPI(title="MyApp API")

# Healthcheck (GET + HEAD)
@app.get("/health", include_in_schema=False)
@app.head("/health", include_in_schema=False)
def health():
    return {"status": "ok"}

# Редирект с корня на Swagger-документацию
@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/docs")

